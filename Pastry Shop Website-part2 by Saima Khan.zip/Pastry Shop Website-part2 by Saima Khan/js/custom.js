function box() {
	alert('Thanks for Your Order! Please insert your credit card number. ');
}